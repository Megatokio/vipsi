/******************************************************************************
/**
 * @file	main.cpp
 * @brief	test file
 * @author  Takayuki HARUKI (University of Salford, UK)
 * @since	Sep. 2007
 *
 ******************************************************************************/

#include <stdio.h>

#include "CmRandomNumberGenerator.h"

void init();
void term();

/******************************************************************************
/**
 * @note	Test file for checking random numbers produced by Mersenne Twister
 * @author  Takayuki HARUKI (University of Salford, UK)
 * @data	Sep. 2007
 * @par	how to use
 *			-# get singleton object by using getInstance
 *			-# change seed by changeSeed if you want
 *			-# get random number by calling getFloat or getDouble functions
 *			-# call release finally only at once
 *
 ******************************************************************************/
int main(int argc, char *argv[])
{
	init();

	// get random number generator singleton
	CmRandomNumberGenerator* pRandomNumberGenerator = CmRandomNumberGenerator::getInstance();
	if (NULL == pRandomNumberGenerator)
	{
		return -1;
	}

	// get double type random number
	double dValue = pRandomNumberGenerator->getDouble();

	FILE* fpLog = fopen("log.txt", "w");
	if (NULL != fpLog)
	{
		// check for random number we got
		fprintf(fpLog, "%f\n", dValue);

		fclose (fpLog);
		fpLog = NULL;
	}

	term();

	return 0;
}

void init()
{
}

void term()
{
	CmRandomNumberGenerator* pRandomNumberGenerator = CmRandomNumberGenerator::getInstance();
	if (NULL != pRandomNumberGenerator)
	{
		// destroy singleton object
		pRandomNumberGenerator->release();
		pRandomNumberGenerator = NULL;
	}
}
